package com.cognizant.employeemanagementsystem.service;

import com.cognizant.employeemanagementsystem.entity.Employee;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeCriteriaService {

    @PersistenceContext
    private EntityManager entityManager;

    public List<Employee> getAllEmployees() {

        CriteriaBuilder builder =
                entityManager.getCriteriaBuilder();

        CriteriaQuery<Employee> query =
                builder.createQuery(Employee.class);

        Root<Employee> root =
                query.from(Employee.class);

        query.select(root);

        return entityManager
                .createQuery(query)
                .getResultList();
    }
}