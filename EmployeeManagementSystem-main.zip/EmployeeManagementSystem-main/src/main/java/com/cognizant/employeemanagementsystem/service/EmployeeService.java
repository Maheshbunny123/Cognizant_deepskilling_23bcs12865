﻿package com.cognizant.employeemanagementsystem.service;

import com.cognizant.employeemanagementsystem.entity.Employee;
import com.cognizant.employeemanagementsystem.repository.EmployeeRepository;
import com.cognizant.employeemanagementsystem.projection.EmployeeProjection;
import org.springframework.data.jpa.repository.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id).orElse(null);
    }

    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }

    public Employee getEmployeeByName(
            String name){

        return employeeRepository
                .findByName(name);
    }

    public Employee getEmployeeByEmail(
            String email){

        return employeeRepository
                .findByEmail(email);
    }

    public List<Employee>
    getEmployeesByNameContaining(
            String name){

        return employeeRepository
                .findByNameContaining(name);
    }

    public Employee
    findByEmployeeName(
            String name){

        return employeeRepository
                .findByEmployeeName(name);
    }

    public List<Employee>
    getEmployeesStartingWith(
            String name){

        return employeeRepository
                .findByNameStartingWith(
                        name);
    }

    public Employee
    getEmployeeByNameAndEmail(
            String name,
            String email){

        return employeeRepository
                .findByNameAndEmail(
                        name,
                        email);
    }

    public Page<Employee> getEmployees(
            int page,
            int size){

        Pageable pageable =
                PageRequest.of(page,size);

        return employeeRepository
                .findAll(pageable);
    }

    public List<Employee>
    getEmployeesSortedByName(){

        return employeeRepository.findAll(
                Sort.by("name"));
    }

    public List<EmployeeProjection>
    getEmployeeProjection(){

        return employeeRepository
                .findAllProjectedBy();
    }

    public List<Employee> getAllEmployeesHQL() {
        return employeeRepository
                .getAllEmployeesHQL();
    }

    public Employee getEmployeeByNameHQL(
            String name) {

        return employeeRepository
                .getEmployeeByNameHQL(name);
    }

    public Employee getEmployeeByEmailHQL(
            String email) {

        return employeeRepository
                .getEmployeeByEmailHQL(email);
    }

    public List<Employee> searchByName(
            String text) {

        return employeeRepository
                .searchByName(text);
    }

    public List<Employee> getEmployeesOrderByName() {

        return employeeRepository
                .getEmployeesOrderByName();
    }

    public Long countEmployees() {

        return employeeRepository
                .countEmployees();
    }

    public List<Employee>
    getEmployeesFetchDepartment() {

        return employeeRepository
                .getEmployeesFetchDepartment();
    }

    public List<Employee>
    getAllEmployeesNative() {

        return employeeRepository
                .getAllEmployeesNative();
    }
}