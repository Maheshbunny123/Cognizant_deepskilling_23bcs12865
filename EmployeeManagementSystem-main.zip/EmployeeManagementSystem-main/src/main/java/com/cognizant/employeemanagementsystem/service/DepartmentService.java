package com.cognizant.employeemanagementsystem.service;

import com.cognizant.employeemanagementsystem.entity.Department;
import com.cognizant.employeemanagementsystem.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    public Department saveDepartment(
            Department department){

        return departmentRepository.save(
                department);
    }

    public List<Department>
    getAllDepartments(){

        return departmentRepository.findAll();
    }
}