package com.cognizant.employeemanagementsystem.controller;

import com.cognizant.employeemanagementsystem.entity.Employee;
import com.cognizant.employeemanagementsystem.service.EmployeeService;
import com.cognizant.employeemanagementsystem.projection.EmployeeProjection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Page;
import java.util.List;
import com.cognizant.employeemanagementsystem.service.EmployeeCriteriaService;
@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;
    @Autowired
    private EmployeeCriteriaService employeeCriteriaService;
    @GetMapping
    public List<Employee> getAllEmployees() {
        return employeeService.getAllEmployees();
    }

    @GetMapping("/{id}")
    public Employee getEmployeeById(
            @PathVariable Long id) {

        return employeeService
                .getEmployeeById(id);
    }

    @PostMapping
    public Employee saveEmployee(
            @RequestBody Employee employee){

        return employeeService
                .saveEmployee(employee);
    }

    @DeleteMapping("/{id}")
    public String deleteEmployee(
            @PathVariable Long id){

        employeeService.deleteEmployee(id);

        return "Employee Deleted";
    }

    @GetMapping("/name/{name}")
    public Employee getEmployeeByName(
            @PathVariable String name){

        return employeeService
                .getEmployeeByName(name);
    }

    @GetMapping("/email/{email}")
    public Employee getEmployeeByEmail(
            @PathVariable String email){

        return employeeService
                .getEmployeeByEmail(email);
    }

    @GetMapping("/search/{name}")
    public List<Employee>
    searchEmployees(
            @PathVariable String name){

        return employeeService
                .getEmployeesByNameContaining(
                        name);
    }

    @GetMapping("/starts/{name}")
    public List<Employee>
    getEmployeesStartingWith(
            @PathVariable String name){

        return employeeService
                .getEmployeesStartingWith(
                        name);
    }

    @GetMapping("/search")
    public Employee
    getEmployeeByNameAndEmail(

            @RequestParam String name,
            @RequestParam String email){

        return employeeService
                .getEmployeeByNameAndEmail(
                        name,
                        email);
    }

    @GetMapping("/page")
    public Page<Employee> getEmployees(

            @RequestParam(defaultValue = "0")
            int page,

            @RequestParam(defaultValue = "5")
            int size){

        return employeeService
                .getEmployees(page,size);
    }

    @GetMapping("/sort")
    public List<Employee>
    getEmployeesSortedByName(){

        return employeeService
                .getEmployeesSortedByName();
    }

    @GetMapping("/projection")
    public List<EmployeeProjection>
    getEmployeeProjection() {

        return employeeService
                .getEmployeeProjection();
    }


    @GetMapping("/hql")
    public List<Employee>
    getAllEmployeesHQL(){

        return employeeService
                .getAllEmployeesHQL();
    }

    @GetMapping("/hql/name/{name}")
    public Employee
    getEmployeeByNameHQL(
            @PathVariable String name) {

        return employeeService
                .getEmployeeByNameHQL(name);
    }

    @GetMapping("/hql/email/{email}")
    public Employee
    getEmployeeByEmailHQL(
            @PathVariable String email) {

        return employeeService
                .getEmployeeByEmailHQL(email);
    }

    @GetMapping("/hql/search/{text}")
    public List<Employee>
    searchByName(
            @PathVariable String text) {

        return employeeService
                .searchByName(text);
    }

    @GetMapping("/hql/sort")
    public List<Employee>
    getEmployeesOrderByName() {

        return employeeService
                .getEmployeesOrderByName();
    }

    @GetMapping("/hql/count")
    public Long countEmployees() {

        return employeeService
                .countEmployees();
    }

    @GetMapping("/hql/fetch")
    public List<Employee>
    getEmployeesFetchDepartment() {

        return employeeService
                .getEmployeesFetchDepartment();
    }

    @GetMapping("/native")
    public List<Employee>
    getAllEmployeesNative() {

        return employeeService
                .getAllEmployeesNative();
    }

    @GetMapping("/named/{name}")
    public Employee
    findByEmployeeName(
            @PathVariable String name){

        return employeeService
                .findByEmployeeName(name);
    }

    @GetMapping("/criteria")
    public List<Employee> getEmployeesCriteria() {

        return employeeCriteriaService
                .getAllEmployees();
    }


}