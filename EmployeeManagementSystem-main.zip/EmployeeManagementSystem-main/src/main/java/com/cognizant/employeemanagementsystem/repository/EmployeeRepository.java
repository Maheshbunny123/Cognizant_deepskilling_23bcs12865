package com.cognizant.employeemanagementsystem.repository;

import com.cognizant.employeemanagementsystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cognizant.employeemanagementsystem.projection.EmployeeProjection;
import org.springframework.data.jpa.repository.Query;
import java.util.List;


@Repository
public interface EmployeeRepository
        extends JpaRepository<Employee,Long> {

    Employee findByName(String name);

    Employee findByEmail(String email);

    List<Employee> findByNameContaining(
            String name);

     Employee findByEmployeeName(
            String name);

    List<Employee>
    findByNameStartingWith(
            String name);

    Employee findByNameAndEmail(
            String name,
            String email);

    List<EmployeeProjection>
    findAllProjectedBy();

    @Query("SELECT e FROM Employee e")
    List<Employee> getAllEmployeesHQL();

    @Query("SELECT e FROM Employee e WHERE e.name=?1")
    Employee getEmployeeByNameHQL(String name);

    @Query("SELECT e FROM Employee e WHERE e.email=?1")
    Employee getEmployeeByEmailHQL(String email);

    @Query("""

            SELECT e
FROM Employee e
WHERE e.name LIKE CONCAT('%', ?1, '%')
""")
    List<Employee> searchByName(String text);

    @Query("SELECT e FROM Employee e ORDER BY e.name ASC")
    List<Employee> getEmployeesOrderByName();

    @Query("SELECT COUNT(e) FROM Employee e")
    Long countEmployees();

    @Query("""
            
SELECT e
FROM Employee e
JOIN FETCH e.department
""")
    List<Employee> getEmployeesFetchDepartment();

    @Query(
            value = "SELECT * FROM employee",
            nativeQuery = true
    )
    List<Employee> getAllEmployeesNative();

    }